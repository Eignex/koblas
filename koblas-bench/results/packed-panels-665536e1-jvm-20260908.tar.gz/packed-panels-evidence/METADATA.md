# Packed panel benchmark evidence

- Feature commit: `665536e171643356b08de2f75b9c9d76caa3c825`
- Baseline commit: `b45af3e2` (`origin/main` before this branch)
- Date: 2026-09-08
- Host: 12th Gen Intel Core i9-12900H, Linux x86-64, JDK 25.0.1
- Affinity: logical CPUs `0,2,4,6`
- Harness: JMH average time, one fork, three 500 ms warmups, five 500 ms measurements
- Parameters: depths `3,31,128`; full `8x4` and partial `7x3` tile edges
- Invocation: `JAVA_TOOL_OPTIONS=-Djmh.ignoreLock=true taskset -c 0,2,4,6 ./gradlew :koblas-bench:jvmSelectedBenchmark --no-daemon --rerun-tasks -Pbench.include=PackedPanelBenchmark.*|PackedPanelExecutionBenchmark.*`

The two feature passes were deliberately independent and ran on a busy shared host. Their wide confidence intervals and between-pass spread are retained rather than filtered. Every `packLeft`, `packRight`, `writeLeft`, and `writeRight` setup probe reported `0 B/call` in both logs.

`reusedPanelProduct` is a retained-kernel sanity arm, not part of the helper implementation. Its depth-three full-tile row failed the managed-allocation guard in both feature passes; the partial row failed in pass 1 and passed in pass 2. `main-baseline-depth3.log` reproduces the full-tile failure on untouched `origin/main`, while `main-baseline-depth31.json` preserves the successful depth-31 baseline run. This is evidence of a pre-existing JVM SIMD intrinsification/inlining instability, not a helper regression.

No OpenBLAS or oneMKL comparison is recorded because neither library exposes an API for packing or writing koblas's private microkernel panel layout. End-to-end BLAS comparisons would measure a different operation and would not provide a defensible helper ratio.

Contents:

- `packed-panel-pass1.json`, `packed-panel-pass2.json`: raw successful JMH rows.
- `packed-panel-pass1.log`, `packed-panel-pass2.log`: complete console logs, including allocation probes and rejected rows.
- `main-baseline-depth31.json`: untouched-main successful depth-31 rows.
- `main-baseline-depth3.json`, `main-baseline-depth3.log`: untouched-main depth-3 reproduction.
- `GemmTileAllocationBaselineBenchmark.kt`: temporary baseline harness used only in the detached baseline worktree.
- `summary.tsv`: paired feature scores and pass-2/pass-1 ratios.
