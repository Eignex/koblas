package com.eignex.koblas.bench

import com.eignex.koblas.dense.F64Kernels
import kotlinx.benchmark.*

@State(Scope.Benchmark)
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(BenchmarkTimeUnit.NANOSECONDS)
class GemmTileAllocationBaselineBenchmark {
    @Param("3", "31")
    var depth: Int = 3

    @Param("full", "partial")
    var edge: String = "full"

    private lateinit var kernels: F64Kernels
    private lateinit var packedA: DoubleArray
    private lateinit var packedB: DoubleArray
    private lateinit var c: DoubleArray

    @Setup
    fun setup() {
        kernels = explicitBuiltInContext().kernels
        val rows = if (edge == "full") kernels.gemmTileRows else kernels.gemmTileRows - 1
        val columns = if (edge == "full") kernels.gemmTileCols else kernels.gemmTileCols - 1
        packedA = DoubleArray(depth * kernels.gemmTileRows) { index ->
            if (index % kernels.gemmTileRows < rows) index * 0.001 else 0.0
        }
        packedB = DoubleArray(depth * kernels.gemmTileCols) { index ->
            if (index % kernels.gemmTileCols < columns) index * 0.002 else 0.0
        }
        c = DoubleArray(kernels.gemmTileRows * kernels.gemmTileCols)
        println()
        verifyNearZeroManagedAllocation("baseline-gemm-tile/$depth/$edge") {
            kernels.gemmTile(depth, packedA, 0, packedB, 0, c, 0, kernels.gemmTileRows)
        }
        println("resolved: baseline-gemm-tile kernels=${kernels.name}")
    }

    @Benchmark
    fun reusedPanelProduct(): DoubleArray {
        kernels.gemmTile(depth, packedA, 0, packedB, 0, c, 0, kernels.gemmTileRows)
        return c
    }
}
