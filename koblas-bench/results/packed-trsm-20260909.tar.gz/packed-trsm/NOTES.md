# Packed TRSM benchmark evidence

Measured on a busy shared 12th Gen Intel Core i9-12900H host with OpenJDK 22.0.2. The measured tree was the
source-equivalent pre-stack-rebase commit `5d7cb41d`. Confidence intervals in the JVM JSON are consequently
wider than on an isolated host; no task was paused to obtain these measurements.

All comparator runs set `OPENBLAS_NUM_THREADS=1`, `OMP_NUM_THREADS=1`, and `MKL_NUM_THREADS=1`. The oneMKL
run additionally used the existing `/home/rasmus/intel/oneapi/mkl/2026.1/lib` runtime with
`MKL_THREADING_LAYER=SEQUENTIAL` and `MKL_DYNAMIC=FALSE`. Benchmark setup reported `openblas/cblas` and
`onemkl/cblas`, each with one thread.

- `fused-jvm-pass1.json` and `fused-jvm-pass2.json` are independent retained-panel comparisons at depths 3,
  31, and 128. The fused JVM tile is faster at depths 3 and 31 in both passes and overlaps or trails the
  separate product plus solve slightly at 128. Every JVM setup probe measured 0 B/call for packed TRSM,
  fused GEMM-TRSM, and the product tile.
- `fused-native.json` is the corresponding Kotlin/Native C-kernel comparison. Direct fusion preserves the
  stepwise subtraction semantics but is slower at shallow depths and reaches near parity at depth 128.
- `trsm-packed.json` and `trsm-scalar.json` force end-to-end built-in TRSM packing on and off across order
  boundaries, narrow/wide panels, both sides, both triangles, transpose, and unit diagonal.
- `trsm-row-boundary-packed.json` and `trsm-row-boundary-scalar.json` isolate normalized row counts 7, 8, 9,
  15, 16, 17, 31, 32, and 33 at order 32. Packing loses below 16, overlaps through 31, and is 1.12x to
  1.59x faster at 32 and 33, supporting the compiled-in row threshold of 32.
- `trsm-openblas.json` and `trsm-onemkl.json` compare the default built-in dispatch with the benchmark-owned
  single-threaded CBLAS implementations. Both external libraries remain faster; the files establish the
  implementation identity and comparison gap without treating them as production dependencies.

An explicit Vector API prototype was rejected before these retained runs because it allocated. Direct probes
measured about 3.4 KB/call for dispatched TRSM and 768 B/call for direct fused TRSM, while the final JVM path
measures 0 B/call by keeping vector values inside established inline/scalarized helpers.
