# Packed triangular SIMD edge evidence

- Base: `d39aefbea455fa900d07110a465e93902a88cd55` (`origin/main` on 2026-09-09).
- Candidate: `0320cab7`.
- Host: Linux x86-64, Intel Core i9-12900H, JVM Vector API with four double lanes.
- Affinity: `taskset -c 0,2,4,6`.
- JMH: three 500 ms warmups, five 500 ms measurements, one fork.
- Concurrency: another JMH process held the global lock, so `-Djmh.ignoreLock=true` was used. All results are busy-host evidence and retain their confidence intervals.
- Threading: end-to-end OpenBLAS used `OPENBLAS_NUM_THREADS=1` and `OMP_NUM_THREADS=1`.

The baseline and candidate commands selected `ExplicitPackedKernelBenchmark.gemmTrsmTile`,
`separateGemmAndTrsm`, and `trsmTile` at depths 3, 31, and 128 for full and partial tiles. The benchmark
change makes the fixture derive its tile shape from the selected kernels; on this host SIMD uses 8x4 and
the partial case is 7x3. The candidate variant pass additionally covers upper/unit-diagonal arithmetic.

Lower/non-unit partial GEMM-TRSM results from the first stable before/after pair:

| depth | baseline ns/op | candidate ns/op | speedup |
| ---: | ---: | ---: | ---: |
| 3 | 92.612 +/- 4.940 | 36.390 +/- 1.105 | 2.55x |
| 31 | 284.303 +/- 15.805 | 69.661 +/- 2.016 | 4.08x |
| 128 | 1999.855 +/- 123.451 | 193.280 +/- 3.769 | 10.35x |

Every retained successful JVM setup reports `0 B/call` for the packed update/solve. A temporary helper
version caused the depth-3 allocation probe to reject its fork and was removed; the retained candidate code
keeps every `DoubleVector` local. `candidate-edges-pass2.json` is a second complete edge-only pass after that
removal (41.318, 89.927, and 263.377 ns/op); it is visibly noisier but preserves the same conclusion.

The end-to-end OpenBLAS pass is retained as residual-gap evidence, not a parity claim. On the busy host the
built-in rows ranged from 11.7 to 84.7 us and OpenBLAS from 2.19 to 62.3 us, with several wide overlapping
intervals. The masked leaf removes a clear edge-only bottleneck, but packing, eligibility scanning, and the
remaining solve dominate some ordinary TRSM cases. oneMKL was not installed. ARM and macOS were unmeasured.

The SIMD edge has no exact external-library counterpart because it consumes koblas-private padded panels.
External comparison is therefore made only for equivalent end-to-end BLAS TRSM work.

`native-validation.json` records the unchanged Linux x86-64 scalar and compiled-C leaves with the now
platform-shaped fixture across both directions, diagonal modes, edges, and depths. Native managed-allocation
measurement is unavailable. The run completed successfully; it is validation evidence, not a claim that the
JVM-only masked implementation changes Native performance.
