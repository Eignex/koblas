# Packed triangular SIMD edge evidence

- Production base: `d39aefbea455fa900d07110a465e93902a88cd55`.
- Corrected benchmark-only baseline: `8a9a0249` (benchmark commit plus the review fix, without the SIMD edge implementation).
- Candidate benchmark fix: `74e41d80` on PR #506.
- Host: Linux x86-64, Intel Core i9-12900H, JVM Vector API with four double lanes.
- Affinity: `taskset -c 0,2,4,6`.
- JMH: three 500 ms warmups, five 500 ms measurements, one fork.
- Concurrency: runs tolerated other work; `-Djmh.ignoreLock=true` was used. Confidence intervals and cross-pass variation are retained.

The corrected fixture derives the SIMD 8x4 tile shape from the selected kernels and measures its 7x3 edge.
`lower-nonunit` now explicitly sets `unitDiag=false` and stores diagonal 1.25, so the solve performs division
by a value distinguishable from one. `upper-unit` explicitly sets `unitDiag=true` and is the no-division control.
The GEMM allocation probe uses the selected tile-row count as its leading dimension.

Corrected JVM results in ns/op:

| variant | depth | baseline pass 1 | baseline pass 2 | candidate pass 1 | candidate pass 2 |
| --- | ---: | ---: | ---: | ---: | ---: |
| lower non-unit | 3 | 122.899 | 123.473 | 65.758 | 137.458 |
| lower non-unit | 31 | 301.424 | 340.610 | 107.245 | 102.876 |
| lower non-unit | 128 | 2019.710 | 2074.274 | 230.593 | 235.605 |
| upper unit | 3 | 95.319 | 131.863 | 38.472 | 37.103 |
| upper unit | 31 | 277.089 | 298.411 | 79.365 | 83.041 |
| upper unit | 128 | 2033.545 | 2418.805 | 207.449 | 200.441 |

The busy-host depth-3 lower/non-unit result is inconclusive across passes (0.90x to 1.88x). The retained
point estimates improve 2.81x to 3.31x at depth 31 and 8.76x to 8.80x at depth 128. Unit-diagonal point
estimates improve 2.48x to 3.55x, 3.49x to 3.59x, and 9.80x to 12.07x respectively. Every successful
candidate allocation probe reports `0 B/call`.

`native-validation.json` refreshes the affected fixture on unchanged Linux x86-64 scalar and C leaves for
both variants and all three depths. Native managed-allocation measurement is unavailable. The end-to-end
OpenBLAS JSON is unaffected by the fixture fix and remains residual-gap evidence rather than a parity claim.
OpenBLAS was single-threaded. oneMKL was unavailable; ARM and macOS performance remain unmeasured.

The SIMD edge has no exact external-library counterpart because it consumes koblas-private padded panels.
External comparison therefore remains limited to equivalent end-to-end BLAS TRSM work.
