# Sparse workspace and C-dispatch benchmark evidence

These files preserve the raw JSON and console logs used for the sparse workspace and JVM/Native packed-kernel
work based on main commit `d3148d5a`. They were measured on a busy shared Intel Core i9-12900H host with CPU
affinity `0,2,4,6`, three 500 ms warmups, and five 500 ms measurements. Other builds and benchmark suites remained
active. The wide JVM intervals and cross-pass variation are retained; they are not an idle-host claim. A stale JMH
global lock held by another running suite required `-Djmh.ignoreLock=true`. Native allocation probes report
unavailable by design; the warmed JVM probes reported `0 B/call` for every sparse workspace and packed leaf row.

## Sparse workspace

`sparse-workspace-jvm-pass1` and `pass2` are independent JVM runs at touched counts 8, 64, 512, and 4096.
`native-pass1` and `pass2` contain the corresponding Native rows at 8, 512, and 4096 alongside the packed work.
All five public operations use caller-owned arrays, and measured work scales with the supplied touched/input slice;
none scans the full workspace dimension. The benchmark method names `activeMaxAbs` and
`filterCandidatePositions` are shorter benchmark labels for the final public methods `activeColumnMaxAbs` and
`pivotCandidatePositions`.

## JVM C crossovers

`dense-c-postmerge-pass1` and `pass2` compare scalar and raw bundled-C `axpy4` and `dotAxpy` after the segment cache
removed per-call FFM wrapper allocation. The two passes support conservative defaults of 64 elements for `axpy4`
and 256 for `dotAxpy`: below those points C loses or the passes disagree, while both passes favor C from those
boundaries upward. Every relevant allocation probe reports `0 B/call`.

`packed-c-crossover-pass2` and `packed-jvm-raw-c-final-pass2` are independent raw-C packed tile probes; the tuning
properties were set below dispatch so the C arm could not silently execute the portable fallback. The latter adds
the depth-16 boundary. Raw C can lose for a partial fused tile at depth 3, while full and partial product/fused
tiles lead at depth 16 and separate further at 128. `packed-jvm-final-dispatch` verifies the installed depth-16
defaults: scalar and C-provider rows share the portable path at depth 3, and the provider selects C at 16 and 128.
Standalone C TRSM was measured and rejected because it did not win consistently, so standalone tile solves remain
portable.

## Eligibility and end-to-end solve

`trsm-eligibility-pass1` and `pass2` isolate the unchanged conservative guard from #494. In the constructed
dense-finite scenario it reports 0% fallback; in the deliberately late structural-zero and overflow-bound scenarios
it reports 100% fallback. Those are scenario outcomes, not an estimate of workload-wide fallback frequency.

`packed-trsm-e2e-jvm-pass1` and `pass2` repeat full right-transposed solves with retained workspaces. At shape
`16x32` the C provider is near scalar; at `32x32` it is roughly 1.4--1.6x faster, and at `64x128` roughly 2.25x.
Both Native passes likewise retain eligible and structural-zero end-to-end rows. Ineligible inputs continue through
the reference-semantic fallback; no timing result was used to weaken the eligibility predicate.

The Native passes also compare scalar and compiled-in C packed leaves on identical final code. They provide the
second-target evidence for the register-resident full/edge fused update and solve. The first Native pass additionally
retains the explicit separate GEMM-plus-TRSM composition.
